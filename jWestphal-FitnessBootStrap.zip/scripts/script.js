/*
    Student Name: Jacob Westphal
    File Name: script.js
    Date: 11/30/20
*/


$(document).ready(function() {
    $('.hero').height($(window).height());
});